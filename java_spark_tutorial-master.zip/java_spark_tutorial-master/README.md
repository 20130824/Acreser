Spark MVC Tutorial
===================

See the entire walkthrough on my [blog](http://taywils.me/2013/11/05/javasparkframeworktutorial.html)

## Instructions

- For each of the steps outlined on the blog post just _git checkout_ the corresponding branch name

- Or just follow along and read through the blog article

You're welcome
